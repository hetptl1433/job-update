# Orbit Finance on AWS

This directory deploys Orbit's Plaid backend as an AWS serverless stack:

- API Gateway HTTP API with a Google ID-token JWT authorizer
- one Node.js Lambda function
- DynamoDB pay-per-request storage
- a customer-managed KMS key for Plaid Item access tokens
- Secrets Manager access for the existing Plaid credentials
- public, signed Plaid webhook handling
- short-lived, user-scoped Plaid Hosted Link sessions for free Apple Personal Teams

No Plaid secret or permanent access token is returned to the iPhone.

## Prerequisites

1. Install AWS CLI v2 and AWS SAM CLI.
2. Sign in with `aws configure sso` and verify with `aws sts get-caller-identity`.
3. Create the Plaid secret in the same AWS region as the stack. Copy its ARN,
   not its value.
4. Own an HTTPS endpoint for Plaid webhooks. The deployed
   `https://api.ipodeskai.com` custom domain satisfies this requirement.
5. An Apple Team ID and Associated Domains are required only for the original
   native Plaid SDK/Universal Link flow. They are not required for the
   developer-only Hosted Link flow described below.

The Secrets Manager JSON must contain:

```json
{
  "PLAID_CLIENT_ID": "stored-in-aws",
  "PLAID_SECRET": "stored-in-aws"
}
```

`PLAID_ENV` is a deployment parameter, not a secret. The current Plaid Trial
uses `production` and real financial data.

## Deploy

From this directory:

```bash
npm ci
npm test
sam validate --lint
sam build
sam deploy --guided
```

Use these guided values:

```text
Stack name: orbit-finance-production
Region: us-east-2
PlaidSecretArn: ARN copied from Secrets Manager
PlaidEnvironment: production
GoogleClientID: Orbit's existing Google iOS client ID
PlaidRedirectURI: https://api.ipodeskai.com/plaid/oauth
PlaidWebhookURL: https://api.ipodeskai.com/api/plaid/webhook
HostedLinkCompletionURI: orbit://finance
AppleAppID: VN6463GX9K.com.hetpatel.jobradar
Allow SAM CLI IAM role creation: Yes
Disable rollback: No
Save arguments to configuration file: Yes
```

Do not put the Plaid secret itself into a SAM parameter. The generated
`samconfig.toml` is ignored by Git because it contains account-specific values.

## Configure the custom domain

The first deployment outputs an API Gateway URL. Configure the custom domain so
Plaid can reach the signed webhook endpoint:

1. Request an ACM certificate in `us-east-2` for `api.ipodeskai.com`.
2. In API Gateway, create the Regional custom domain `api.ipodeskai.com` with
   that certificate.
3. Map the custom domain's root path to the generated Orbit HTTP API and its
   `$default` stage.
4. Add the API Gateway alias record to the domain's DNS.
5. Confirm these URLs return without a redirect:
   - `https://api.ipodeskai.com/health`
   - `https://api.ipodeskai.com/.well-known/apple-app-site-association`
   - `https://api.ipodeskai.com/plaid/complete`
6. Register `https://api.ipodeskai.com/plaid/oauth` under Plaid Dashboard's
   allowed redirect URIs.
7. Add `applinks:api.ipodeskai.com` only when using the original native Plaid
   SDK flow with a paid Apple Developer team. Do not add it for Hosted Link on
   a free Personal Team.

The AASA endpoint returns `503` until `AppleAppID` is configured. This avoids
Apple caching an empty association file.

## Connect Orbit

Set the deployed custom URL in the root `project.yml`:

```yaml
FinanceAPIBaseURL: "https://api.ipodeskai.com/"
```

Keep `APIBaseURL` empty unless a separate backend implements Orbit's optional
job tracker and push routes.

Regenerate the Xcode project and rebuild:

```bash
xcodegen generate
```

The app sends its refreshed Google ID token in the `Authorization` header.
API Gateway validates the Google signature, issuer, expiry, and iOS client-ID
audience before Lambda runs. Lambda scopes every DynamoDB record to the token's
stable `sub` claim.

### Free Apple Personal Team: Hosted Link

The authenticated app calls `POST /api/plaid/hosted-link`. Lambda creates a
30-minute Plaid Hosted Link session with these important properties:

- `hosted_link.is_mobile_app` is `true`.
- `hosted_link.completion_redirect_uri` is `orbit://finance`.
- the top-level `redirect_uri` is the allowlisted
  `https://api.ipodeskai.com/plaid/oauth` URL. Plaid requires both URI fields
  when `hosted_link.is_mobile_app` is `true`.

The iPhone opens the returned `hostedLinkURL` in `ASWebAuthenticationSession`
or external Safari. Plaid returns to Orbit with its custom URL scheme when the
session finishes. This does not require Apple's Associated Domains entitlement.

On a free Apple Personal Team, iOS does not claim that HTTPS redirect as a
Universal Link, so Chase may use a browser-first flow and the redirect can open
the hosted fallback page before Plaid finishes. The final Hosted Link callback
still uses `orbit://finance`. This is appropriate for a personal/demo build,
but a public production app should use a paid Apple Developer membership and
Associated Domains for reliable bank app-to-app OAuth.

Orbit never receives or stores the raw Hosted Link token. The server stores a
SHA-256 hash mapped to the authenticated Google `sub`, a random connection ID,
and an enforced expiration. DynamoDB TTL removes the mapping later. Plaid sends
a signed `LINK/ITEM_ADD_RESULT` or `LINK/SESSION_FINISHED` webhook; only after
signature, environment, token ownership, expiration, and replay checks pass
does Lambda exchange the public token. The webhook performs only the lightweight
token exchange and encrypted Item save so it can answer Plaid quickly. Orbit
then calls the authenticated transaction sync endpoint.

The creation response is:

```json
{
  "hostedLinkURL": "https://secure.plaid.com/link/...",
  "connectionID": "4b6947f1-7096-4fce-8c79-b16d9eb3ed80",
  "expiresAt": "2026-08-09T23:00:00.000Z"
}
```

Poll `GET /api/plaid/hosted-link/{connectionID}` after Orbit becomes active.
Its `data.status` is one of `pending`, `processing`, `complete`, `exited`,
`failed`, or `expired`. The public `/plaid/complete` page provides a manual
**Open Orbit** button as a fallback; it contains no user or financial data.

## Routes

Authenticated with Google:

- `POST /api/plaid/hosted-link`
- `GET /api/plaid/hosted-link/{id}`
- `POST /api/plaid/link-token`
- `POST /api/plaid/exchange-public-token`
- `GET /api/plaid/overview`
- `POST /api/plaid/transactions/sync`
- `DELETE /api/plaid/items/{id}`

Public by design:

- `POST /api/plaid/webhook` - verifies Plaid's ES256 signature, age, and body hash
- `GET /health`
- `GET /.well-known/apple-app-site-association`
- `GET /plaid/oauth`
- `GET /plaid/complete` - generic `orbit://finance` fallback page

Opening Plaid Link again connects another institution. Each connection remains
owned by the same authenticated Orbit user.

## Production safety

- Never log request bodies, public tokens, access tokens, credentials, or raw
  financial provider responses.
- Keep Sandbox and Production DynamoDB stacks separate if Sandbox is added.
- Rotate any Plaid secret that has been exposed in screenshots or chat before
  connecting a real institution.
- `sam delete` removes the table and KMS key created by this stack. Export or
  disconnect data first if it must be retained.
